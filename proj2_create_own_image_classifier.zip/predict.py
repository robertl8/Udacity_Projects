import warnings
warnings.filterwarnings('ignore')

import json

import os
import numpy as np
import matplotlib.pyplot as plt

import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_datasets as tfds
tfds.disable_progress_bar()

import logging
logger = tf.get_logger()
logger.setLevel(logging.ERROR)

from PIL import Image
from tensorflow import keras

import argparse
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('img_path', action='store', help='path to input image path')
    parser.add_argument('model_path', action='store', help='path to saved model')
    parser.add_argument('--top_k', action='store', type=int, default=1, help='top most likely classes')
    parser.add_argument('--category_names', action='store', help='mapping labels to flower names')
    args=parser.parse_args()
    return parser.parse_args()


def process_image(image_array):
    image_tensor = tf.convert_to_tensor(image_array)
    image_tensor_resize = tf.image.resize(image_tensor, [224,224])
    image_tensor_resize = tf.cast(image_tensor_resize, tf.float32)
    image_tensor_resize /= 255
    image_array = image_tensor_resize.numpy()
    return image_array

def predict(my_image_path, my_model, top_k):
    im = Image.open(my_image_path)
    test_image = np.asarray(im)
    processed_test_image = process_image(test_image)
    processed_test_image_batch = np.expand_dims(processed_test_image, axis=0)
    ps = my_model.predict(processed_test_image_batch)
    ps = ps[0].tolist()
    values, indices = tf.math.top_k(ps, k=top_k)
    my_probs = values.numpy().tolist()
    indices += 1
    my_classes = indices.numpy().tolist()
    return my_probs, my_classes

#parse arguments
args = parse_args()
model = keras.models.load_model('./'+args.model_path, custom_objects={'KerasLayer':hub.KerasLayer})

with open(args.category_names, 'r') as f:
    class_names = json.load(f)

image_path = args.img_path
original_image = np.asarray(Image.open(image_path))

predict(image_path, model, int(args.top_k))
probs, classes = predict(image_path, model, int(args.top_k))

realname = classes
i=0
for class_num in classes:
    realname[i] = class_names[str(class_num)]
    i += 1

fig, (ax1, ax2) = plt.subplots(figsize=(10,8), ncols=2)
ax1.imshow(original_image)
ax1.axis('off')
ax2.barh(np.arange(0,int(args.top_k)), probs)
ax2.set_aspect(0.1)
ax2.set_yticks(np.arange(0,int(args.top_k)))
ax2.set_yticklabels(realname, size='small');
ax2.set_title('Class Probability')
ax2.set_xlim(0, 1.1)
plt.tight_layout()
plt.show()
